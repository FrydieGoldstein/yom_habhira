import React from "react";
import EventForm from "../crud-form/components/EventForm";

const EventsForm = () => {
  return (
    <div dir="rtl">
      <EventForm />
    </div>
  );
};

export default EventsForm;
