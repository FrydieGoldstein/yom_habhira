import React, { useContext } from "react";
import { useParams } from "react-router-dom";
import { EventContext } from "../contexts/EventContext";

const EventDetails = () => {
  const { id } = useParams();
  const { events } = useContext(EventContext);

  const event = events.find((e) => e.id === id);

  if (!event) {
    return <div>No event data available</div>;
  }

  return (
    <div>
      <h1>Event Details</h1>
      <p>Event ID: {event.id}</p>
      <p>Event Name: {event.title.hebrew}</p>
      <p>Lecturer: {event.lecturer.name.hebrew}</p>
      {/* הוסיפי כאן עוד פרטים ועיצוב לפי הצורך */}
    </div>
  );
};

export default EventDetails;
