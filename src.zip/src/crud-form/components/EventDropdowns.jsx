// EventDropdowns.jsx

import React, { useEffect, useState } from "react";
import { Grid, FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import { readEvents } from "../crud/readEvent";

export const EventDropdowns = () => {
  return <></>;
};
