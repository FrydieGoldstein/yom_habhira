// import React from "react";
// import { Box, Button } from "@mui/material";
// import { useLanguage } from "../../contexts/LanguageContext";

// const FilterButtons = ({ handleOpenFilter }) => {
//   const { translations } = useLanguage();
//   return (
//     <Box
//       sx={{
//         width: "100%",
//         overflow: "auto",
//         display: "flex",
//         justifyContent: "center",
//       }}
//     >
//       <Button onClick={() => handleOpenFilter(translations.topics)}>{translations.topics}</Button>
//       <Button onClick={() => handleOpenFilter(translations.time)}>{translations.time}</Button>
//       <Button onClick={() => handleOpenFilter(translations.location)}>{translations.location}</Button>
//       <Button onClick={() => handleOpenFilter(translations.language)}>{translations.language}</Button>
//     </Box>
//   );
// };

// export default FilterButtons;
