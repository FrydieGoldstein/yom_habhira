import React from "react";
import { Button, Box, Typography } from "@mui/material";
import { Cities, Countries } from "../constants/enums";

const LocationFilterDrawer = ({ onLocationChange, selectedLocation }) => {
  // Ensure selectedLocation is an array before using it
  selectedLocation = selectedLocation || [];

  const handleToggle = (location) => {
    const newSelectedLocations = selectedLocation.includes(location)
      ? selectedLocation.filter((loc) => loc !== location)
      : [...selectedLocation, location];
    onLocationChange(newSelectedLocations);
  };

  const handleSelectIsraelCities = () => {
    let newSelectedLocations = [...selectedLocation];
    const cityKeys = Object.keys(Cities);

    if (selectedLocation.includes("ISRAEL")) {
      // If Israel is selected, remove Israel and all cities
      newSelectedLocations = newSelectedLocations.filter((loc) => loc !== "ISRAEL" && !cityKeys.includes(loc));
    } else {
      // If Israel is not selected, add Israel and all cities
      newSelectedLocations = [...new Set([...newSelectedLocations, "ISRAEL", ...cityKeys])];
    }

    onLocationChange(newSelectedLocations);
  };

  const handleToggleCity = (city) => {
    let newSelectedLocations = selectedLocation.includes(city) ? selectedLocation.filter((loc) => loc !== city) : [...selectedLocation, city];

    const allCitiesSelected = Object.keys(Cities).every((city) => newSelectedLocations.includes(city));

    if (allCitiesSelected && !newSelectedLocations.includes("ISRAEL")) {
      newSelectedLocations.push("ISRAEL");
    } else if (!allCitiesSelected && newSelectedLocations.includes("ISRAEL")) {
      newSelectedLocations = newSelectedLocations.filter((loc) => loc !== "ISRAEL");
    }

    onLocationChange(newSelectedLocations);
  };

  //   console.log(selectedLocation);

  return (
    <Box sx={{ width: "auto", padding: 2 }}>
      <Typography variant="h6" sx={{ marginBottom: 2 }}>
        ישראל
      </Typography>
      {Object.entries(Cities).map(([key, value]) => (
        <Button
          key={key}
          onClick={() => handleToggleCity(key)}
          variant={selectedLocation.includes(key) ? "contained" : "outlined"}
          sx={{ margin: 1 }}
        >
          {value}
        </Button>
      ))}
      <Typography variant="h6" sx={{ marginY: 2 }}>
        שאר העולם
      </Typography>
      {Object.entries(Countries).map(([key, value]) => (
        <Button
          key={key}
          onClick={() => (key === "ISRAEL" ? handleSelectIsraelCities() : handleToggle(key))}
          variant={
            selectedLocation.includes(key) || (key === "ISRAEL" && Object.keys(Cities).every((city) => selectedLocation.includes(city)))
              ? "contained"
              : "outlined"
          }
          sx={{ margin: 1 }}
        >
          {value}
        </Button>
      ))}
    </Box>
  );
};

export default LocationFilterDrawer;
