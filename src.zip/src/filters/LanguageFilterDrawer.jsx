import React from "react";
import { Button, Box } from "@mui/material";
import { Language } from "../constants/enums";

const LanguageFilterDrawer = ({ onLanguageChange, selectedLanguage }) => {
  const handleToggle = (language) => {
    const newSelectedLanguages = selectedLanguage.includes(language)
      ? selectedLanguage.filter((lang) => lang !== language)
      : [...selectedLanguage, language];
    onLanguageChange(newSelectedLanguages);
  };

  return (
    <Box sx={{ width: "auto", padding: 2 }}>
      {Object.entries(Language).map(([key, value]) => (
        <Button key={key} onClick={() => handleToggle(key)} variant={selectedLanguage.includes(key) ? "contained" : "outlined"} sx={{ margin: 1 }}>
          {value}
        </Button>
      ))}
    </Box>
  );
};

export default LanguageFilterDrawer;
